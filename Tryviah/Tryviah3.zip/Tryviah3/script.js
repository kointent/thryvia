function toggleSidebar() {
    const sidebar = document.querySelector('.admin-sidebar');
    sidebar.classList.toggle('active');
    
    // Change icon between Bars and X
    const icon = document.querySelector('.menu-toggle i');
    if (sidebar.classList.contains('active')) {
        icon.classList.replace('fa-bars', 'fa-xmark');
    } else {
        icon.classList.replace('fa-xmark', 'fa-bars');
    }
}

// Close sidebar when clicking a link on mobile
document.querySelectorAll('.admin-nav a').forEach(link => {
    link.addEventListener('click', () => {
        if (window.innerWidth <= 992) {
            toggleSidebar();
        }
    });
});

function toggleProductModal() {
        const modal = document.getElementById('productModal');
        modal.classList.toggle('active');
    }
     function toggleProductModal() {
        const modal = document.getElementById('productModal');
        modal.classList.toggle('active');
        
    }
    function openCustomerProfile() {
    document.getElementById('customerDrawer').classList.add('active');
    document.getElementById('customerOverlay').classList.add('active');
}

function closeCustomerProfile() {
    document.getElementById('customerDrawer').classList.remove('active');
    document.getElementById('customerOverlay').classList.remove('active');
}

 function toggleProductModal() {
        const modal = document.getElementById('productModal');
        modal.classList.toggle('active');
    }

    function openOrderDetails() {
    document.getElementById('orderDrawer').classList.add('active');
    document.getElementById('orderDrawerOverlay').classList.add('active');
}

function closeOrderDrawer() {
    document.getElementById('orderDrawer').classList.remove('active');
    document.getElementById('orderDrawerOverlay').classList.remove('active');
}

function showTab(tabId) {
            // Hide all panes
            document.querySelectorAll('.settings-pane').forEach(p => p.classList.remove('active'));
            // Deactivate all nav buttons
            document.querySelectorAll('.s-nav-btn').forEach(b => b.classList.remove('active'));
            
            // Show selected pane
            const targetPane = document.getElementById(tabId);
            if(targetPane) targetPane.classList.add('active');

            // Find the button that was clicked and set it to active
            const clickedBtn = Array.from(document.querySelectorAll('.s-nav-btn')).find(btn => btn.getAttribute('onclick').includes(tabId));
            if(clickedBtn) clickedBtn.classList.add('active');
        }

        function toggleSlider(sliderId) {
            const slider = document.getElementById(sliderId);
            const overlayId = sliderId.replace('Slider', 'Overlay');
            const overlay = document.getElementById(overlayId);
            
            if(slider && overlay) {
                slider.classList.toggle('active');
                overlay.classList.toggle('active');
            }
        }

        function saveAllSettings() {
            alert("All changes saved successfully.");
        }

        // Handle Change Buttons in Curation
        document.addEventListener('click', function(e) {
            if(e.target.classList.contains('change-btn')) {
                alert("Opening Media Library...");
            }
        });

        const emailBodyInput = document.getElementById('emailBody');
const bodyPreview = document.getElementById('bodyPreview');

if(emailBodyInput && bodyPreview) {
    emailBodyInput.addEventListener('input', function() {
        // Simple newline to <br> conversion for preview
        bodyPreview.innerHTML = this.value.replace(/\n/g, "<br>");
    });
}
function toggleSidebar() {
    const sidebar = document.querySelector('.admin-sidebar');
    const icon = document.querySelector('.menu-toggle i');
    
    sidebar.classList.toggle('active');
    
    if (sidebar.classList.contains('active')) {
        icon.classList.replace('fa-bars', 'fa-xmark');
    } else {
        icon.classList.replace('fa-xmark', 'fa-bars');
    }
}

function openAdminSlider(name, email, role) {
    // Fill the slider with the specific user's data
    document.getElementById('editAdminName').value = name;
    document.getElementById('editAdminEmail').value = email;
    document.getElementById('editAdminRole').value = role;
    
    // Show the slider
    toggleSlider('adminSlider');
}

function saveAdminChanges() {
    const name = document.getElementById('editAdminName').value;
    alert(`Account for ${name} has been updated.`);
    toggleSlider('adminSlider');
}
// Generic Slider Toggle - Works for adminSlider, couponSlider, etc.
function toggleSlider(sliderId) {
    const slider = document.getElementById(sliderId);
    
    // This turns 'adminSlider' into 'adminOverlay' automatically
    const overlayId = sliderId.replace('Slider', 'Overlay'); 
    const overlay = document.getElementById(overlayId);
    
    if (slider && overlay) {
        slider.classList.toggle('active');
        overlay.classList.toggle('active');
    } else {
        console.error("Could not find slider or overlay. Check your IDs!");
    }
}

// Function for clicking "Add Member"
function openAddAdminSlider() {
    document.getElementById('adminSliderTitle').innerText = "Add Team Member";
    document.getElementById('adminSubmitBtn').innerText = "Create Account";
    document.getElementById('adminNameInput').value = "";
    document.getElementById('adminEmailInput').value = "";
    
    document.getElementById('adminPasswordGroup').style.display = "block";
    document.getElementById('editAdminActions').style.display = "none";
    
    toggleSlider('adminSlider');
}

// Function for clicking an admin's Name
function openEditAdminSlider(name, email, role) {
    document.getElementById('adminSliderTitle').innerText = "Edit Administrator";
    document.getElementById('adminSubmitBtn').innerText = "Update Info";
    
    document.getElementById('adminNameInput').value = name;
    document.getElementById('adminEmailInput').value = email;
    document.getElementById('adminRoleInput').value = role;
    
    document.getElementById('adminPasswordGroup').style.display = "none";
    document.getElementById('editAdminActions').style.display = "block";
    
    toggleSlider('adminSlider');
}
// Function for clicking "+ New Product"
function openAddProductSlider() {
    document.getElementById('productSliderTitle').innerText = "Add New Product";
    document.getElementById('productSubmitBtn').innerText = "Publish Product";
    
    // Clear form
    document.getElementById('pNameInput').value = "";
    document.getElementById('pPriceInput').value = "";
    document.getElementById('pDescInput').value = "";
    
    document.getElementById('editProductActions').style.display = "none";
    toggleSlider('productSlider');
}

// Function for clicking the "Edit" button on a product row
function openEditProductSlider(name, category, price, desc) {
    document.getElementById('productSliderTitle').innerText = "Edit Product";
    document.getElementById('productSubmitBtn').innerText = "Update Product";
    
    // Fill form with existing data
    document.getElementById('pNameInput').value = name;
    document.getElementById('pCategoryInput').value = category;
    document.getElementById('pPriceInput').value = price;
    document.getElementById('pDescInput').value = desc;
    
    document.getElementById('editProductActions').style.display = "block";
    toggleSlider('productSlider');
}
// Function to preview selected image
function previewProductImage(input) {
    const preview = document.getElementById('pImagePreview');
    const placeholder = document.getElementById('uploadPlaceholder');
    
    if (input.files && input.files[0]) {
        const reader = new FileReader();
        reader.onload = function(e) {
            preview.src = e.target.result;
            preview.style.display = 'block';
            placeholder.style.display = 'none';
        }
        reader.readAsDataURL(input.files[0]);
    }
}

// Function to open "Add" mode
function openAddProductSlider() {
    document.getElementById('productSliderTitle').innerText = "Add New Product";
    document.getElementById('productSubmitBtn').innerText = "Publish Product";
    document.getElementById('gallerySection').style.display = 'none';
    
    // Clear gallery images
    ['pGal1Preview', 'pGal2Preview', 'pGal3Preview'].forEach(id => {
        document.getElementById(id).style.display = 'none';
        document.getElementById(id).src = "";
    });
    ['pGal1Icon', 'pGal2Icon', 'pGal3Icon'].forEach(id => {
        document.getElementById(id).style.display = 'block';
    });
    
    toggleSlider('productSlider');
    
    // Reset form and image
    document.getElementById('productForm').reset();
    document.getElementById('pImagePreview').style.display = 'none';
    document.getElementById('uploadPlaceholder').style.display = 'block';
    
    document.getElementById('editProductActions').style.display = "none";
    toggleSlider('productSlider');
}

// Function to open "Edit" mode with data
function openEditProductSlider(name, category, price, desc, imageUrl) {
    document.getElementById('productSliderTitle').innerText = "Edit Product";
    document.getElementById('productSubmitBtn').innerText = "Update Product";
    
    // Fill fields
    document.getElementById('pNameInput').value = name;
    document.getElementById('pCategoryInput').value = category;
    document.getElementById('pPriceInput').value = price;
    document.getElementById('pDescInput').value = desc;
    
    // Show existing image
    const preview = document.getElementById('pImagePreview');
    const placeholder = document.getElementById('uploadPlaceholder');
    if(imageUrl) {
        preview.src = imageUrl;
        preview.style.display = 'block';
        placeholder.style.display = 'none';
    }
    
    document.getElementById('editProductActions').style.display = "block";
    toggleSlider('productSlider');
}

// Handle the Main Image and reveal the gallery
function handleMainImage(input) {
    const preview = document.getElementById('pMainPreview');
    const placeholder = document.getElementById('mainPlaceholder');
    const gallery = document.getElementById('gallerySection');
    
    if (input.files && input.files[0]) {
        const reader = new FileReader();
        reader.onload = function(e) {
            preview.src = e.target.result;
            preview.style.display = 'block';
            placeholder.style.display = 'none';
            
            // REVEAL the gallery section
            gallery.style.display = 'block';
        }
        reader.readAsDataURL(input.files[0]);
    }
}

// Handle the 3 Gallery Images
function previewGallery(input, previewId, iconId) {
    const preview = document.getElementById(previewId);
    const icon = document.getElementById(iconId);
    
    if (input.files && input.files[0]) {
        const reader = new FileReader();
        reader.onload = function(e) {
            preview.src = e.target.result;
            preview.style.display = 'block';
            icon.style.display = 'none';
        }
        reader.readAsDataURL(input.files[0]);
    }
}

function filterOrders(status, btn) {
    // 1. Handle Active Button Styling
    const tabs = document.querySelectorAll('.tab-btn');
    tabs.forEach(tab => tab.classList.remove('active'));
    btn.classList.add('active');

    // 2. Filter the Table Rows
    const rows = document.querySelectorAll('.admin-table tbody tr');
    
    rows.forEach(row => {
        if (status === 'all') {
            row.style.display = ''; // Show all
        } else {
            // Check if the row has the class that matches the status
            if (row.classList.contains(status)) {
                row.style.display = ''; // Show match
            } else {
                row.style.display = 'none'; // Hide others
            }
        }
    });
}

// Function to open the Email Slider
function openEmailSlider() {
    // 1. Grab the email from the Profile Drawer
    const customerEmail = document.getElementById('profileEmail').innerText;
    const customerName = document.getElementById('profileName').innerText;

    // 2. Set the recipient and a default subject
    document.getElementById('emailRecipient').value = customerEmail;
    document.getElementById('emailSubject').value = `Hello ${customerName},`;
    
    // 3. Clear the previous message
    document.getElementById('emailBody').value = "";

    // 4. Open the email slider (Z-index ensures it sits on top)
    toggleSlider('emailSlider');
}

function sendEmailAction() {
    const recipient = document.getElementById('emailRecipient').value;
    const message = document.getElementById('emailBody').value;

    if(!message) {
        alert("Please type a message before sending.");
        return;
    }

    // Simulate sending
    alert("Email sent successfully to " + recipient);
    
    // Close the slider
    toggleSlider('emailSlider');
}

// Function to handle the "Send" button
function sendEmailAction() {
    alert("Email sent successfully!");
    toggleSlider('emailSlider');
}